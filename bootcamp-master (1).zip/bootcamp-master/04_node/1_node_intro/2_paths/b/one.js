module.exports = {
    first: function() {
        console.log('   *');
    },
    second: function() {
        console.log('  * ');
    }    
}