module.exports = {
 logger: function(val) {
     console.log(val);
 }   
}