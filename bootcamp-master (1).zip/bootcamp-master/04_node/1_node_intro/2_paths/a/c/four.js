module.exports = {
    not_horizons: '?!!!',
    horizons: '*'
};