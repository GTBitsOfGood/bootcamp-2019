module.exports = {
    logger: function(val) { console.log("Plural of moose is not " + val); },
    value: 'meese'
}