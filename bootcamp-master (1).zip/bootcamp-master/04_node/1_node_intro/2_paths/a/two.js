module.exports = {
    twoFunc: function() {
        console.log(' *  ');
    } 
}