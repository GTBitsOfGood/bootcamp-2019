# Function Arguments

## Goal

The goal of this exercise is to familiarize yourself with the JavaScript function `arguments` object.

## Instructions

1. Open `02_javascript/4_function_arguments/var_args.js` in your text editor. Exercise details are listed there.
2. Open `02_javascript/4_function_arguments/var_args.html` in your browser to run tests.
3. Write necessary functions to make all the tests pass.
