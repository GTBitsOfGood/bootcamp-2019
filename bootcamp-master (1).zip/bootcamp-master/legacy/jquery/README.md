# jQuery Exercises

1. [Collapsible comment threads](comment_threads/README.md)
2. [Making Horello dynamic](horello_dynamic/README.md)
3. [Bonus: jQuery challenges](bonus_jquery.md)
