# jQuery bonus exercises

1. Complete all of the jQuery challenges here:
   http://try.jquery.com/levels/1/sections/1
1. Complete these challenges as well:
   http://tutorialzine.com/2014/05/javascript-challenge-make-me-blue/
1. Create this parallax effect: http://www.jqueryrain.com/?AaF5WbuX
1. Mimic the effects on this page using jQuery:
   http://www.jqueryrain.com/?ZHUn9QBT
1. Try to recerate these parallax effects: http://petarstojakovic.net/
1. Try to recreate these parallax effects (element stays in focus as you
   scroll down, then changes): http://nasaprospect.com/ - There is
   another site with a similar effect here:
   http://www.nytimes.com/interactive/2015/10/27/world/greenland-is-melting-away.html
1. Try to recreate the parallax effects here:
   http://www.kennedyandoswald.com/
