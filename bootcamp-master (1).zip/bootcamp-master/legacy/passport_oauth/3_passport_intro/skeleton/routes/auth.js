// imports n' things
var router = require('express').Router();

module.exports = function(passport) {
  // YOUR CODE HERE
  
  
  
  return router;
};
