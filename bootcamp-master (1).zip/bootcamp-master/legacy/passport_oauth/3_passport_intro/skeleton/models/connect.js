module.exports = "YOUR MONGO URI HERE";
