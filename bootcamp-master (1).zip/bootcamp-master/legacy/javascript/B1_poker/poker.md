# Bonus Exercise: Poker Hands

## Goal

The goal of this exercise is to build a function that takes two poker hands and
determines which one is the winner. It requires you to handle many fallback
conditions for tie breakers.

## Instructions

1. Open `1_javascript/B1_poker/poker.js` in your text editor. Exercise details are listed there.
2. Open `1_javascript/B1_poker/poker.html` in your browser to run tests.
3. Write necessary functions to make all the tests pass.

