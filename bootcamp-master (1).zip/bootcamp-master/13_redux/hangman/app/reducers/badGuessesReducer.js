/* Reducer for the badGuesses substate */
/* This reducer's state will be a simple integer */

// import * as types from '../actions/types';

// const badGuessesReducer =

// export default badGuessesReducer;
