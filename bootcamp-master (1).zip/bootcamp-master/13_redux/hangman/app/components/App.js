import React from 'react';

import GameContainer from '../containers/GameContainer';

const App = () =>
    <div>
        <h1>Redux Hangman</h1>
        <GameContainer />
    </div>;

export default App;
